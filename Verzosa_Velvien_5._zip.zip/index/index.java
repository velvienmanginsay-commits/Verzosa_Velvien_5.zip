import javax.swing.*;
import java.awt.*;

public class index {
    public static void main(String[] args) {

        JFrame frame = new JFrame("Campus Registration");
        frame.setSize(600, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JTextField name = new JTextField(10);
        JTextField age = new JTextField(2);
        JTextField college = new JTextField(10);

        JComboBox<String> event = new JComboBox<>(
            new String[]{
                "Select Event",
                "Programming Competition",
                "Web Design Challenge",
                "Cybersecurity Seminar",
                "AI and Emerging Technologies",
                "IT Quiz Bowl"
            }
        );

        JRadioButton participant =
            new JRadioButton("Student Participant");
        JRadioButton audience =
            new JRadioButton("Student Audience");
        JRadioButton faculty =
            new JRadioButton("Faculty/Staff");

        ButtonGroup group = new ButtonGroup();
        group.add(participant);
        group.add(audience);
        group.add(faculty);

        JCheckBox java = new JCheckBox("Java Programming");
        JCheckBox web = new JCheckBox("Web Development");
        JCheckBox cyber = new JCheckBox("Cybersecurity");
        JCheckBox ai = new JCheckBox("Artificial Intelligence");
        JCheckBox database = new JCheckBox("Database Management");

        JTextArea notes = new JTextArea(3, 20);

        JButton register = new JButton("REGISTER");
        JButton clear = new JButton("CLEAR");

        frame.add(new JLabel("Participant Name:"));
        frame.add(name);
        frame.add(new JLabel("Age:"));
        frame.add(age);
        frame.add(new JLabel("College/Department:"));
        frame.add(college);
        frame.add(new JLabel("Event Category:"));
        frame.add(event);

        frame.add(new JLabel("Attendance Type:"));
        frame.add(participant);
        frame.add(audience);
        frame.add(faculty);

        frame.add(new JLabel("Workshops:"));
        frame.add(java);
        frame.add(web);
        frame.add(cyber);
        frame.add(ai);
        frame.add(database);

        frame.add(new JLabel("Special Request:"));
        frame.add(new JScrollPane(notes));

        frame.add(register);
        frame.add(clear);

        register.addActionListener(e -> {
            if (name.getText().trim().isEmpty()
                    || age.getText().trim().isEmpty()
                    || college.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(
                    frame, "Please complete the required fields."
                );
                return;
            }

            int number;

            try {
                number = Integer.parseInt(age.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(
                    frame, "Age must be a whole number."
                );
                return;
            }

            if (number <= 0) {
                JOptionPane.showMessageDialog(
                    frame, "Age must be greater than zero."
                );
                return;
            }

            if (event.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(
                    frame, "Please select an event."
                );
                return;
            }

            if (!participant.isSelected()
                    && !audience.isSelected()
                    && !faculty.isSelected()) {
                JOptionPane.showMessageDialog(
                    frame, "Select an attendance type."
                );
                return;
            }

            String attendance = participant.isSelected()
                    ? "Student Participant"
                    : audience.isSelected()
                    ? "Student Audience"
                    : "Faculty/Staff";

            String workshops = "";

            if (java.isSelected()) workshops += "Java Programming\n";
            if (web.isSelected()) workshops += "Web Development\n";
            if (cyber.isSelected()) workshops += "Cybersecurity\n";
            if (ai.isSelected()) workshops += "Artificial Intelligence\n";
            if (database.isSelected()) workshops += "Database Management\n";

            if (workshops.isEmpty()) workshops = "None";

            String summary =
                "Name: " + name.getText() +
                "\nAge: " + number +
                "\nCollege: " + college.getText() +
                "\nEvent: " + event.getSelectedItem() +
                "\nAttendance: " + attendance +
                "\nWorkshops:\n" + workshops +
                "\nSpecial Request: " + notes.getText();

            JOptionPane.showMessageDialog(
                frame, summary, "Registration Summary",
                JOptionPane.INFORMATION_MESSAGE
            );
        });

        clear.addActionListener(e -> {
            name.setText("");
            age.setText("");
            college.setText("");
            event.setSelectedIndex(0);
            group.clearSelection();
            java.setSelected(false);
            web.setSelected(false);
            cyber.setSelected(false);
            ai.setSelected(false);
            database.setSelected(false);
            notes.setText("");
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}